-- Create database
CREATE DATABASE IF NOT EXISTS AMAZONSALES;
CREATE TABLE IF NOT EXISTS SALES (
    invoice_id VARCHAR(30) NOT NULL PRIMARY KEY,
    branch VARCHAR(30) NOT NULL,
    city VARCHAR(30) NOT NULL,
    customer_type VARCHAR(30) NOT NULL,
    gender VARCHAR(10) NOT NULL,
    product_line VARCHAR(100) NOT NULL,
    unit_price DECIMAL(10, 2) NOT NULL,
    quantity INT NOT NULL,
    VAT FLOAT(6, 4) NOT NULL,
    total DECIMAL(10, 2) NOT NULL,
    date DATE NOT NULL,
    time TIME NOT NULL,
    payment_method VARCHAR(30) NOT NULL,
    cogs DECIMAL(10, 2) NOT NULL,
    gross_margin_percentage FLOAT NOT NULL,
    gross_income DECIMAL(10, 2),
    rating FLOAT(2, 1)
);

-- ------------------------------------------------------------------------------------------------------------------------------------------
-- ---------------------------------------------------------Feature Engineering-------------------------------------------------------------

-- time_of_day
SELECT
    time,
    (CASE 
      WHEN time BETWEEN '00:00:00' AND '12:00:00' THEN 'MORNING'
      WHEN time BETWEEN '12:01:00' AND '16:00:00' THEN 'AFTERNOON'
      ELSE 'EVENING'
    END) AS time_of_day
FROM sales;

ALTER TABLE sales ADD COLUMN time_of_day VARCHAR(20);

-- For this to work turn off safe mode for update
-- Edit > Preferences > SQL Edito > scroll down and toggle safe mode
-- Reconnect to MySQL: Query > Reconnect to server
UPDATE sales
SET time_of_day = (
    	CASE
		WHEN `time` BETWEEN "00:00:00" AND "12:00:00" THEN "Morning"
        WHEN `time` BETWEEN "12:01:00" AND "16:00:00" THEN "Afternoon"
        ELSE "Evening"
    END
);

-- Add day_name column
SELECT
	date,
	DAYNAME(date)
FROM sales; 

ALTER TABLE sales ADD COLUMN day_name VARCHAR(10);

UPDATE sales
SET day_name = DAYNAME(date);

-- Add month_name column
SELECT
	date,
	MONTHNAME(date)
FROM sales; 

ALTER TABLE sales ADD COLUMN month_name VARCHAR(10);

UPDATE sales
SET month_name = MONTHNAME(date);

-- ------------------------------------------------------------------------------------------------------------------------------------------
-- ------------------------------------------------------------ QUESTIONS ---------------------------------------------------------------------
-- -------------------------------------------------------------------------------------------------------------------------------------------

-- --What is the count of distinct cities in the dataset?
SELECT 
	DISTINCT city
FROM sales; 

-- --For each branch, what is the corresponding city?
SELECT
    branch,
    city
FROM
    SALES
GROUP BY
    branch, city;
    
 -- --------What is the count of distinct product lines in the dataset?
 SELECT COUNT(DISTINCT product_line) AS distinct_product_line_count
FROM SALES;

-- ----------Which payment method occurs most frequently?
SELECT
    payment_method,
    COUNT(*) AS payment_method_count
FROM
    SALES
GROUP BY
    payment_method
ORDER BY
    payment_method_count DESC
LIMIT 1;

-- -------Which product line has the highest sales?
SELECT
    product_line,
    SUM(total) AS total_sales
FROM
    SALES
GROUP BY
    product_line
ORDER BY
    total_sales DESC
LIMIT 1;


-- ----How much revenue is generated each month?
SELECT
    DATE_FORMAT(date, '%Y-%m') AS month_year,
    SUM(total) AS monthly_revenue
FROM
    SALES
GROUP BY
    month_year
ORDER BY
    month_year;
    
-- ---------In which month did the cost of goods sold reach its peak?
SELECT
    DATE_FORMAT(date, '%Y-%m') AS month_year,
    SUM(cogs) AS monthly_cogs
FROM
    SALES
GROUP BY
    month_year
ORDER BY
    monthly_cogs DESC
LIMIT 1;

-- -----Which product line generated the highest revenue?
SELECT
    product_line,
    SUM(total) AS total_revenue
FROM
    SALES
GROUP BY
    product_line
ORDER BY
    total_revenue DESC
LIMIT 1;

-- ----In which city was the highest revenue recorded?
SELECT
    city,
    SUM(total) AS total_revenue
FROM
    SALES
GROUP BY
    city
ORDER BY
    total_revenue DESC
LIMIT 1;




-- ----Which product line incurred the highest Value Added Tax?
SELECT
    product_line,
    SUM(VAT) AS total_VAT
FROM
    SALES
GROUP BY
    product_line
ORDER BY
    total_VAT DESC
LIMIT 1;

-- ----Calculate the average rating for each product line.?
SELECT
    product_line,
    AVG(rating) AS average_rating
FROM
    SALES
GROUP BY
    product_line;
    
-- -------Count the sales occurrences for each time of day on every weekday.
SELECT
    DAYOFWEEK(date) AS weekday,
    HOUR(time) AS hour_of_day,
    COUNT(*) AS sales_occurrences
FROM
    SALES
GROUP BY
    weekday, hour_of_day
ORDER BY
    weekday, hour_of_day;
    
-- ---------Identify the customer type contributing the highest revenue.
SELECT
    customer_type,
    SUM(total) AS total_revenue
FROM
    SALES
GROUP BY
    customer_type
ORDER BY
    total_revenue DESC
LIMIT 1;

-- ------Determine the city with the highest VAT percentage.
SELECT
    city,
    (SUM(VAT) / SUM(total)) * 100 AS vat_percentage
FROM
    SALES
GROUP BY
    city
ORDER BY
    vat_percentage DESC
LIMIT 1;

-- -------Identify the customer type with the highest VAT payments.
SELECT
    customer_type,
    SUM(VAT) AS total_VAT_payments
FROM
    SALES
GROUP BY
    customer_type
ORDER BY
    total_VAT_payments DESC
LIMIT 1;

-- -----What is the count of distinct customer types in the dataset?
SELECT
    COUNT(DISTINCT customer_type) AS distinct_customer_type_count
FROM
    SALES;
	
-- -----What is the count of distinct payment methods in the dataset?
SELECT
    COUNT(DISTINCT payment_method) AS distinct_payment_method_count
FROM
    SALES;
    
-- ----Which customer type occurs most frequently?
SELECT
    customer_type,
    COUNT(*) AS frequency
FROM
    SALES
GROUP BY
    customer_type
ORDER BY
    frequency DESC
LIMIT 1;

-- ----Identify the customer type with the highest purchase frequency.
SELECT
    customer_type,
    COUNT(*) AS purchase_frequency
FROM
    SALES
GROUP BY
    customer_type
ORDER BY
    purchase_frequency DESC
LIMIT 1;

-- ---Determine the predominant gender among customers.
SELECT
    gender,
    COUNT(*) AS gender_frequency
FROM
    SALES
GROUP BY
    gender
ORDER BY
    gender_frequency DESC
LIMIT 1;

-- ----Examine the distribution of genders within each branch.
SELECT
    branch,
    gender,
    COUNT(*) AS gender_count
FROM
    SALES
GROUP BY
    branch, gender
ORDER BY
    branch, gender;

-- ----Identify the time of day when customers provide the most ratings.
SELECT
    HOUR(time) AS hour_of_day,
    COUNT(*) AS rating_count
FROM
    SALES
GROUP BY
    hour_of_day
ORDER BY
    rating_count DESC
LIMIT 1;

-- ---Determine the time of day with the highest customer ratings for each branch.
SELECT
    branch,
    HOUR(time) AS hour_of_day,
    COUNT(*) AS rating_count
FROM
    SALES
GROUP BY
    branch, hour_of_day
ORDER BY
    branch, rating_count DESC;
    
-- ----Identify the day of the week with the highest average ratings.
SELECT
    DAYOFWEEK(date) AS day_of_week,
    AVG(rating) AS average_rating
FROM
    SALES
GROUP BY
    day_of_week
ORDER BY
    average_rating DESC
LIMIT 1;

-- ----Determine the day of the week with the highest average ratings for each branch.
SELECT
    branch,
    DAYOFWEEK(date) AS day_of_week,
    AVG(rating) AS average_rating
FROM
    SALES
GROUP BY
    branch, day_of_week
ORDER BY
    branch, average_rating DESC;
    
-- -------------------------------------------------------------END----------------------------------------------------------------------------


































